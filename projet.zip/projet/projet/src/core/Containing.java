package core;

	/**Interface for ants containers
	 * @author Max
	 */

public interface Containing {
		
	public boolean addInsectIn() ;
	
	public boolean removeInsectIn() ;
	
	public Insect getInsectIn();
	
}