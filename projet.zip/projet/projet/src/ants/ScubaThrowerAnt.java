package ants;

public class ScubaThrowerAnt extends ThrowerAnt {
	
	public ScubaThrowerAnt () {
		super();
		this.watersafe = true;
		this.foodCost = 5;
	}
}
